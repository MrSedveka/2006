package redone.net;

/**
 * Packet builder interface
 * 
 * @author Graham
 */
public interface PacketBuilder {

}
