package redone;

import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.requests.GatewayIntent;
import net.dv8tion.jda.api.utils.MemberCachePolicy;
import javax.security.auth.login.LoginException;
import java.util.Timer;
import java.util.TimerTask;
import redone.game.players.PlayerHandler;

public class DiscordBot {

    private static final String DISCORD_TOKEN = "MTI2NDMwNjAzNTMxMzg3MjkwNw.GNhWrT.ndrmMgk0gL5eyxVXDN5PhO7JNiZw_zdiFBd9mA"; // Replace with your bot token
    private JDA jda;
    private Timer timer;

    public void start() throws LoginException {
        JDABuilder builder = JDABuilder.createDefault(DISCORD_TOKEN);

        // Set your presence
        builder.setActivity(Activity.playing("Elysium06"));

        // Enable necessary intents
        builder.enableIntents(GatewayIntent.GUILD_MEMBERS);

        // Optionally, set cache policy and cache flags if needed
        builder.setMemberCachePolicy(MemberCachePolicy.ALL);

        // Build and start the JDA instance
        jda = builder.build();
        
        // Ensure the bot is ready before starting updates
        try {
            jda.awaitReady();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        updatePresence(); // Start updating presence
    }

    public void updatePresence() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                // Update the presence every minute (adjust as needed)
                int playerCount = PlayerHandler.getPlayerCount();
                String presenceText = "Elysium06 with " + playerCount + " players";
                
                System.out.println("Updating Discord presence: " + presenceText); // Debugging log

                try {
                    jda.getPresence().setActivity(Activity.playing(presenceText));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, 0, 10000); // Update every 60 seconds
    }
}
