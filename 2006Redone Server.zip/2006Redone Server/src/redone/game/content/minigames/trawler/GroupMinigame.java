package redone.game.content.minigames.trawler;
 
public abstract class GroupMinigame {
 
        public abstract WaitingRoom getWaitingRoom();
       
        public abstract String getWaitingRoomMessage();
       
}