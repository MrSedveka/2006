package redone.game.content.skills.farming;

/**
 * Patch
 * @author Andrew (I'm A Boss on Rune-Server and Mr Extremez on Mopar & Runelocus)
 */

public enum Patch {
	

}
