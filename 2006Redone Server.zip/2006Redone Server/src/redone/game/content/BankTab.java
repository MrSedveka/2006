package redone.game.content;

import redone.game.items.Item;
import java.util.ArrayList;
import java.util.List;

public class BankTab {
    private List<Item> items;

    public BankTab() {
        items = new ArrayList<>();
    }

    public List<Item> getItems() {
        return items;
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public void removeItem(Item item) {
        items.remove(item);
    }

    public Item getItem(int index) {
        return items.get(index);
    }
}
