package redone.game.content;

public class BankHandler {

}
