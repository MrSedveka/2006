package redone.game.npcs;

public class NpcList {

	public int npcId;
	public String npcName;
	public int npcCombat;
	public int npcHealth;

	public NpcList(int _npcId) {
		npcId = _npcId;
	}
}
