package org.apollo.jagcached.net.service;

/**
 * Represents a response to a service request.
 * @author Graham
 */
public final class ServiceResponse {

}
